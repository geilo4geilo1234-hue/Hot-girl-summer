export function QuoteSection() {
  return null
}
